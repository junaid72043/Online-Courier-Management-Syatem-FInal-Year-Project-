<style>
.who {
   border-bottom:2px solid red;
}
p,h3 {
color: #555555;
    font-size: 16px;
    font-family: 'Open Sans', sans-serif;
    line-height: 1.6;
}
h3 {
  border-bottom:2px solid black;
  padding:10px;
}
.choose p {
border-left:2px solid black;
border-right:2px solid black;
}
</style>
<body style="background-color:white !important;">
<?php include 'service-master.php';?>
<div class="container">
<h1 style="text-align:center">About us</h1>
<div class="row">
    <div class="col-sm-4">
	  <img class="img-responsive thumbnail" src="images/serv-6.jpg">
	</div>
     <div class="col-sm-8">
         <h2 class="who">WHO WE ARE</h2>
		 <p >We strongly believe that pursuing all of these goals is in our interest and in the interest of all of our stakeholders are us customers, employees, investors and the planet as a whole. We add value to cargo people’s interaction with us, with excellent services or products.</p>
		 <p>Engaging our employees and nurturinvestment on the stock holds market we show concern , by engaging our employees and nurturinvestment on the stock holds market we show concern.</p>
     </div>
</div>
</div>
<div>
<img class="img-responsive " src="images/about-im.png">
</div>
<div class="container">
   <h1 class="text-center">WHY CHOOSE USE</h1>
   <div class="row text-center choose">
      <div class="col-sm-4 ">
	      <h3>24 Hours Support</h3>
		  <p>We are Specialises in international freight forwarding of merchandise.</p>
	  </div>
	  <div class="col-sm-4">
	      <h3>Global supply Chain</h3>
		  <p>Efficiently unleash cross-media information without cross-media value.</p>
	  </div>
	  <div class="col-sm-4">
	      <h3>Mobile Shipment Tracking</h3>
		  <p>We Offers intellgent concepts for road & tail well as complex special services.</p>	  
	  </div>
	  </div>
	     <div class="row text-center choose">
      <div class="col-sm-6 ">
	      <h3>Careful Handling</h3>
		  <p>Cargo HUB are transported at some stage of their journey along world’s roads.</p>
	  </div>
	  <div class="col-sm-6">
	      <h3>Time On Door Delivery</h3>
		  <p>We Offers intellgent concepts for road & tail well as complex special <br>services.</p>
	  </div>
	  </div>
   </div>
</div>
<?php include 'footer.php';?>
</body>